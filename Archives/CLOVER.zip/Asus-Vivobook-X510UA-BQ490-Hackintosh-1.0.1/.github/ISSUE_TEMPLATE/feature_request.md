---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

**What is your laptop model? Does it fit the specs in [README](https://github.com/whatnameisit/Asus-Vivobook-X510UA-BQ490-Catalina-10.15.6-Hackintosh/blob/master/README.md#system-specification)?**

**Is your feature request related to a problem? Please describe.**
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

**Describe the solution you'd like**
A clear and concise description of what you want to happen.

**Additional context**
Add any other context or screenshots about the feature request here.
